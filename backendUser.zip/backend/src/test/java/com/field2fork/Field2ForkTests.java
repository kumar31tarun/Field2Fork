package com.field2fork;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Field2ForkTests {

	@Test
	void contextLoads() {
	}

}
