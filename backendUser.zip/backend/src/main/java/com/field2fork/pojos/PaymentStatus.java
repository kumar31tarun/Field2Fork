package com.field2fork.pojos;

public enum PaymentStatus {
	PENDING,COMPLETED,FAILED

}
