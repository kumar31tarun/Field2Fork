package com.field2fork.pojos;

enum OrderStatus {
    PENDING, SHIPPED, DELIVERED, CANCELLED
}