package com.field2fork.pojos;

public enum ProductStatus {
	LOW_STOCK,IN_STOCK,OUT_OF_STOCK

}
