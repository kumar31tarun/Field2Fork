package com.field2fork.pojos;

public enum PaymentMethod {
	CREDIT_CARD,PAYPAL,BANK_TRANSFER,CASH

}
