package com.field2fork.pojos;

 public enum Role {
    ADMIN, SELLER, BUYER
}
