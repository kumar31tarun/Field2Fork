package com.field2fork.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.field2fork.pojos.Reviews;

public interface ReviewsDao extends JpaRepository<Reviews, Long>{

}
