package com.field2fork.dtos;

import com.field2fork.pojos.Role;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserDTO {
    private String username;
    private String password;
    private String email;
    private Role role;
    private String location;
    private String contactNumber;
    private String address;
}
